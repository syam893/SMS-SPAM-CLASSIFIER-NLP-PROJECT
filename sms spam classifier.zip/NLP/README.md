# 🛡️ SpamGuard NLP: Advanced NLP-Based SMS Spam Classifier
### B.Tech Computer Science & Engineering Capstone Project

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.3%2B-orange.svg)](https://scikit-learn.org/)
[![NLTK](https://img.shields.io/badge/NLTK-3.8%2B-green.svg)](https://www.nltk.org/)
[![Flask](https://img.shields.io/badge/Flask-2.3%2B-black.svg)](https://flask.palletsprojects.com/)
[![SQLite](https://img.shields.io/badge/SQLite-3-lightgrey.svg)](https://www.sqlite.org/)
[![Test Suite](https://img.shields.io/badge/Tests-17%20Passed%20(100%25)-brightgreen.svg)]()

---

## 📌 Project Overview
**SpamGuard NLP** is a production-grade, end-to-end Machine Learning and Natural Language Processing (NLP) system designed to detect, classify, and explain spam, smishing, and fraudulent SMS messages in real-time.

Built strictly adhering to scientific machine learning rigor:
- **Zero Data Leakage:** Preprocessing and vectorizer fitting are strictly isolated to the training split.
- **Genuine Benchmarks:** Evaluated on the official UCI SMS Spam Collection dataset (5,574 raw records $\rightarrow$ 5,160 deduplicated records).
- **Explainable AI (XAI):** Provides local token-level feature attribution (positive spam contributors vs. negative ham contributors) and rule-based heuristic indicator detection (hyperlinks, phone numbers, currency symbols, and urgency keywords).
- **Full-Stack Application:** Includes a high-aesthetic responsive web dashboard, REST API, SQLite persistence, batch scanner, and academic documentation.

---

## 🏆 Model Performance Benchmark (Unseen Test Set: 1,032 Samples)

| Algorithm | 5-Fold CV F1 | Test Accuracy | Precision | Recall | F1-Score | ROC-AUC | False Positives (FP) | False Negatives (FN) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Support Vector Machine (Champion)** | **0.9459** | **99.03%** | **99.17%** | **92.97%** | **95.97%** | **0.9965** | 1 | 9 |
| **Random Forest (150 Trees)** | 0.9206 | 98.64% | 100.00% | 89.06% | 94.21% | 0.9970 | **0** | 14 |
| **Logistic Regression (L2 Regularized)** | 0.9110 | 98.26% | 100.00% | 85.94% | 92.44% | 0.9971 | **0** | 18 |
| **Multinomial Naive Bayes ($\alpha=0.2$)** | 0.9401 | 98.16% | 95.04% | 89.84% | 92.37% | 0.9892 | 6 | 13 |

> **Key Observation for Viva:** In SMS filtering, **Precision is paramount** because a False Positive (marking a legitimate bank OTP or doctor appointment as spam) is catastrophic. Both Logistic Regression and Random Forest achieved **100% precision (zero false positives)**, while Linear SVM achieved the best overall balanced **F1-Score (95.97%)** and **99.03% accuracy**.

---

## 📂 Project Architecture & Directory Structure

```text
NLP/
├── data/
│   ├── raw/
│   │   └── sms_spam_raw.csv           # Raw UCI SMS dataset (5,574 rows)
│   └── processed/
│       └── sms_spam_cleaned.csv       # Deduplicated & cleaned data (5,160 rows)
├── models/
│   ├── best_model_pipeline.joblib     # Serialized winning pipeline (LinearSVC)
│   ├── all_models.joblib              # All 4 trained candidate pipelines
│   ├── vectorizer.joblib              # TF-IDF Vectorizer
│   ├── model_metrics.json             # Evaluated metrics on test data
│   └── vocab_importance.json          # Top Spam and Ham vocabulary coefficients
├── database/
│   ├── db.py                          # SQLite ORM & query manager
│   └── spam_classifier.db             # Persistent SQLite database
├── src/
│   ├── __init__.py                    # Package initializer
│   ├── data_loader.py                 # Dataset ingestion, cleaning, stratified split
│   ├── preprocessor.py                # NLP pipeline (lemmatization, entity masking)
│   ├── feature_engineering.py         # TF-IDF, BoW, and statistical extractors
│   ├── train.py                       # 5-fold CV and model benchmark training
│   ├── evaluate.py                    # Plot generation & error analysis suite
│   ├── explainer.py                   # Token-level XAI feature attribution
│   └── predictor.py                   # Real-time and batch inference engine
├── static/
│   ├── css/
│   │   └── style.css                  # Modern glassmorphism UI & responsive styling
│   ├── js/
│   │   └── app.js                     # Frontend interactive controller
│   └── img/eval/                      # Generated evaluation figures
│       ├── confusion_matrices.png     # 2x2 grid of confusion matrices
│       ├── roc_curves.png             # Multi-model ROC comparison
│       ├── pr_curves.png              # Precision-Recall curves
│       ├── model_comparison.png       # Grouped bar chart benchmark
│       ├── feature_importance.png     # Top 15 Spam vs Ham words
│       └── dataset_distribution.png   # Class ratios and length analysis
├── templates/
│   └── index.html                     # Single-page web application dashboard
├── tests/
│   ├── __init__.py
│   ├── test_preprocessor.py           # NLP tokenizer & normalization tests
│   ├── test_models.py                 # Inference & probability sanity tests
│   ├── test_api.py                    # REST API integration tests
│   └── test_database.py               # SQLite storage and feedback tests
├── docs/
│   ├── ARCHITECTURE.md                # System Architecture & Component Design
│   ├── DFD_AND_UML.md                 # DFD Levels 0-2, UML Class & Use-Case
│   ├── PROJECT_REPORT.md              # University project report format
│   ├── PRESENTATION_SLIDES.md         # PPT defense presentation outline
│   └── VIVA_QUESTIONS.md              # 25+ High-scoring Viva Voce Q&A
├── app.py                             # Flask REST API and server
├── run.py                             # Bootstrap & execution script
├── run.bat                            # Windows double-click launcher
└── requirements.txt                   # Pinned project dependencies
```

---

## ⚡ Quick Start & Execution Guide

### 1. Prerequisites
- Python 3.9+ or Anaconda Python
- Virtual environment (recommended) or existing Conda environment

### 2. Installation
Open your terminal / PowerShell in the project directory:
```powershell
# Clone or navigate to the project directory
cd c:\Users\majji\OneDrive\Desktop\NLP

# Install required dependencies
pip install -r requirements.txt
```

### 3. Run the Complete Application
You can run the application directly with:
```powershell
python run.py
```
*(Or on Windows, simply double-click `run.bat`!)*

When executed, the system automatically:
1. Verifies/creates the SQLite database (`database/spam_classifier.db`).
2. Checks for trained models; if missing, it downloads the dataset, runs 5-fold CV, trains all 4 models, generates evaluation plots, and serializes the artifacts.
3. Launches the web server at: **`http://127.0.0.1:5000`**

### 4. Running Unit & Integration Tests
Run the comprehensive 17-test verification suite:
```powershell
python -m pytest tests/ -v
```

---

## 🌐 REST API Endpoints

### 1. Predict Single SMS
- **Endpoint:** `POST /api/predict`
- **Payload:**
```json
{
  "text": "URGENT! You won £1000 cash. Call 0800123 now!",
  "model": "Support Vector Machine"
}
```
- **Response:**
```json
{
  "prediction": "Spam",
  "is_spam": true,
  "confidence": 99.98,
  "spam_probability": 99.98,
  "ham_probability": 0.02,
  "risk_level": "CRITICAL RISK",
  "explanation": {
    "reasons": [
      "Directs recipient to call a toll/mobile number.",
      "High-frequency spam vocabulary detected: 'phone_token', 'call', 'win', 'prize'."
    ],
    "top_spam_words": [
      {"token": "phone_token", "contribution": 0.7529, "impact": "spam"},
      {"token": "win", "contribution": 0.23, "impact": "spam"}
    ],
    "heuristics": {
      "has_url": false,
      "has_phone": true,
      "detected_phones": ["0800123"],
      "matched_triggers": ["call", "cash", "now", "prize", "win"],
      "heuristic_risk_score": 55
    }
  }
}
```

### 2. Batch Classification
- **Endpoint:** `POST /api/predict-batch`
- **Payload:** `{"messages": ["Hello, how are you?", "Win $500 free cash!"]}`

### 3. Scan History & Statistics
- `GET /api/history?limit=50&filter=spam&search=winner`
- `GET /api/statistics`
- `GET /api/models`
- `POST /api/feedback` (Payload: `{"id": 1, "feedback": "correct"}`)

---

## 📊 Methodology & Key Modules

1. **Dataset Management (`src/data_loader.py`):**
   - Automatically downloads the UCI SMS Spam dataset.
   - Cleans missing values and eliminates 414 duplicate records to prevent data leakage.
   - Applies stratified 80:20 train/test splitting (`random_state=42`).

2. **NLP Preprocessing (`src/preprocessor.py`):**
   - Contraction expansion (`won't` $\rightarrow$ `will not`, `u` $\rightarrow$ `you`).
   - Entity masking with regex: hyperlinks $\rightarrow$ `url_token`, phone numbers $\rightarrow$ `phone_token`, currencies $\rightarrow$ `currency_token`.
   - Tokenization, stopword removal, and WordNet lemmatization.

3. **Feature Engineering (`src/feature_engineering.py`):**
   - TF-IDF Vectorizer with unigrams and bigrams (`ngram_range=(1,2)`), sublinear TF scaling, and 4,000 max features.
   - Statistical metadata extractor: character count, uppercase ratio, digit ratio, exclamation count, and heuristic spam score.

4. **Machine Learning Pipeline (`src/train.py`):**
   - Evaluates Multinomial Naive Bayes, Logistic Regression, Linear SVM (with Platt scaling via `CalibratedClassifierCV`), and Random Forest.
   - Performs 5-Fold Stratified Cross-Validation on the training partition.

5. **Model Explainability (`src/explainer.py`):**
   - Decomposes predictions by computing token-level contribution scores: $Attribution(w) = TFIDF(w) \cdot \beta_w$.
   - Highlights positive tokens (spam indicators) and negative tokens (ham indicators).

6. **Web Dashboard & Persistence:**
   - Single-page interface with dark/light mode, live confidence meter, batch scanner, SQLite history table, and academic viva resources.

---

## 🎓 Academic Documentation
Comprehensive reports and viva defense guides are available in the [`docs/`](file:///c:/Users/majji/OneDrive/Desktop/NLP/docs/) directory:
- [System Architecture](file:///c:/Users/majji/OneDrive/Desktop/NLP/docs/ARCHITECTURE.md)
- [DFD & UML Diagrams](file:///c:/Users/majji/OneDrive/Desktop/NLP/docs/DFD_AND_UML.md)
- [Complete Project Report](file:///c:/Users/majji/OneDrive/Desktop/NLP/docs/PROJECT_REPORT.md)
- [Presentation Slides Outline](file:///c:/Users/majji/OneDrive/Desktop/NLP/docs/PRESENTATION_SLIDES.md)
- [Viva Voce Questions & Answers](file:///c:/Users/majji/OneDrive/Desktop/NLP/docs/VIVA_QUESTIONS.md)
