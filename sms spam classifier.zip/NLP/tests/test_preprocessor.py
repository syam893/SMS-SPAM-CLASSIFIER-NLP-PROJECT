"""
Unit Tests for NLP Preprocessing and Heuristic Indicator Extraction
"""

import pytest
from src.preprocessor import TextPreprocessor, extract_indicators, expand_contractions


def test_contractions_expansion():
    raw = "won't can't u r plz"
    expanded = expand_contractions(raw)
    assert "will not" in expanded
    assert "cannot" in expanded
    assert "you" in expanded
    assert "are" in expanded


def test_url_and_phone_indicator_extraction():
    msg = "Call 0800123456 now or visit http://win-prizes.com/claim to win $1000 cash!"
    ind = extract_indicators(msg)
    assert ind["has_url"] is True
    assert ind["has_phone"] is True
    assert ind["has_currency"] is True
    assert "win" in ind["matched_triggers"]
    assert "cash" in ind["matched_triggers"]
    assert ind["heuristic_risk_score"] >= 70


def test_preprocessor_lemmatization():
    pre = TextPreprocessor(method="lemma", remove_stopwords=True)
    msg = "Meeting friends with fast cars tomorrow"
    cleaned = pre.preprocess(msg)
    tokens = cleaned.split()
    assert "meeting" in tokens or "meet" in tokens
    assert "friend" in tokens
    assert "car" in tokens


def test_preprocessor_edge_cases():
    pre = TextPreprocessor()
    assert pre.preprocess("") == ""
    assert pre.preprocess("   ") == ""
    # Pure 5+ digit numbers are detected and masked as phone_tokens for spam defense
    assert "phone_token" in pre.preprocess("12345 67890")
    assert pre.preprocess("!!! ??? ...") == ""
