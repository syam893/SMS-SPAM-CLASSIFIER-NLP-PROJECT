"""
Unit & Integration Tests for Flask REST API Endpoints
"""

import json
import pytest
from app import app


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_index_route(client):
    res = client.get("/")
    assert res.status_code == 200
    assert b"SpamGuard NLP" in res.data


def test_api_predict_valid_sms(client):
    payload = {"text": "URGENT! You won £1000 cash. Call 0800123 now!"}
    res = client.post("/api/predict", data=json.dumps(payload), content_type="application/json")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "success"
    assert data["prediction"] == "Spam"
    assert data["is_spam"] is True
    assert "explanation" in data


def test_api_predict_empty_text(client):
    payload = {"text": "   "}
    res = client.post("/api/predict", data=json.dumps(payload), content_type="application/json")
    assert res.status_code == 400
    data = res.get_json()
    assert data["status"] == "error"


def test_api_statistics(client):
    res = client.get("/api/statistics")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "success"
    assert "database_stats" in data
    assert "benchmark_data" in data


def test_api_models(client):
    res = client.get("/api/models")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "success"
    assert "models" in data
    assert "best_model" in data


def test_api_history(client):
    res = client.get("/api/history")
    assert res.status_code == 200
    data = res.get_json()
    assert data["status"] == "success"
    assert isinstance(data["history"], list)
