"""
Unit Tests for SQLite Database Storage, Retrieval, and Analytics
"""

import os
import pytest
from database.db import (
    init_db,
    save_prediction,
    get_history,
    get_statistics,
    delete_prediction,
    clear_history,
    update_feedback,
)

TEST_DB = "database/test_spam.db"


@pytest.fixture(autouse=True)
def setup_teardown_db():
    if os.path.exists(TEST_DB):
        try:
            os.remove(TEST_DB)
        except Exception:
            pass
    init_db(TEST_DB)
    clear_history(db_path=TEST_DB)
    yield
    if os.path.exists(TEST_DB):
        try:
            os.remove(TEST_DB)
        except Exception:
            pass


def test_save_and_query_prediction():
    fake_record = {
        "raw_text": "Sample text for DB unit test",
        "cleaned_tokens": "sample text db unit test",
        "prediction": "Spam",
        "confidence": 98.5,
        "spam_probability": 98.5,
        "risk_level": "CRITICAL RISK",
        "model_used": "Support Vector Machine",
        "explanation": {
            "heuristics": {
                "has_url": True,
                "has_phone": False,
                "matched_triggers": ["win", "prize"],
            }
        },
    }
    rec_id = save_prediction(fake_record, db_path=TEST_DB)
    assert rec_id > 0

    history = get_history(limit=10, db_path=TEST_DB)
    assert len(history) == 1
    assert history[0]["id"] == rec_id
    assert history[0]["prediction"] == "Spam"
    assert history[0]["has_url"] == 1
    assert "win" in history[0]["detected_triggers"]


def test_statistics_and_feedback():
    fake_record = {
        "raw_text": "Another test",
        "cleaned_tokens": "another test",
        "prediction": "Ham",
        "confidence": 95.0,
        "spam_probability": 5.0,
        "risk_level": "SAFE",
        "model_used": "Support Vector Machine",
        "explanation": {"heuristics": {"has_url": False, "has_phone": False}},
    }
    rec_id = save_prediction(fake_record, db_path=TEST_DB)
    feedback_ok = update_feedback(rec_id, "correct", db_path=TEST_DB)
    assert feedback_ok is True

    stats = get_statistics(db_path=TEST_DB)
    assert stats["total_scans"] >= 1
    assert stats["ham_scans"] >= 1
