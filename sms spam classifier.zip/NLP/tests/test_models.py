"""
Unit Tests for Model Inference, Probability Calibration, and Pipeline Integrity
"""

import os
import pytest
from src.predictor import get_predictor


@pytest.fixture(scope="module")
def predictor():
    return get_predictor()


def test_predictor_initialization(predictor):
    assert predictor.best_pipeline is not None
    assert len(predictor.all_pipelines) >= 3


def test_obvious_spam_classification(predictor):
    spam_sms = "CONGRATS! You won a $1000 cash prize or free gift card. Call 0800123456 now to claim!"
    res = predictor.predict(spam_sms)
    assert res["prediction"] == "Spam"
    assert res["is_spam"] is True
    assert res["confidence"] > 70.0
    assert res["spam_probability"] > 70.0
    assert len(res["explanation"]["reasons"]) > 0


def test_obvious_ham_classification(predictor):
    ham_sms = "Hey, are you coming to the college library for group study this afternoon?"
    res = predictor.predict(ham_sms)
    assert res["prediction"] == "Ham"
    assert res["is_spam"] is False
    assert res["ham_probability"] > 70.0
    assert res["confidence"] > 70.0


def test_probability_distribution(predictor):
    sms = "Test message for probability sanity verification."
    res = predictor.predict(sms)
    total_prob = round(res["ham_probability"] + res["spam_probability"], 1)
    assert total_prob == 100.0


def test_batch_prediction(predictor):
    batch = [
        "Are you free for lunch?",
        "URGENT: Claim your free lottery ticket now at http://win.pw",
    ]
    results = predictor.predict_batch(batch)
    assert len(results) == 2
    assert results[0]["prediction"] == "Ham"
    assert results[1]["prediction"] == "Spam"
