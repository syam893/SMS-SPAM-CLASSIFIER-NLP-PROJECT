@echo off
title Advanced NLP SMS Spam Classifier - B.Tech CSE Project
echo ======================================================================
echo    ADVANCED NLP-BASED SMS SPAM CLASSIFIER
echo    B.Tech Computer Science ^& Engineering Final Project
echo ======================================================================
echo.

set "PYTHON_CMD="

if exist "%USERPROFILE%\anaconda3\python.exe" (
    set "PYTHON_CMD=%USERPROFILE%\anaconda3\python.exe"
)
if not defined PYTHON_CMD if exist "C:\Users\SAI RAHUL RAJ\anaconda3\python.exe" (
    set "PYTHON_CMD=C:\Users\SAI RAHUL RAJ\anaconda3\python.exe"
)
if not defined PYTHON_CMD if exist "C:\ProgramData\anaconda3\python.exe" (
    set "PYTHON_CMD=C:\ProgramData\anaconda3\python.exe"
)
if not defined PYTHON_CMD (
    where python >nul 2>nul
    if %errorlevel% equ 0 (
        python -c "import sys" >nul 2>nul
        if %errorlevel% equ 0 (
            set "PYTHON_CMD=python"
        )
    )
)

if not defined PYTHON_CMD (
    echo [ERROR] Python not found in PATH or standard Anaconda path!
    pause
    exit /b 1
)

echo Starting application using "%PYTHON_CMD%"...
"%PYTHON_CMD%" run.py
pause

