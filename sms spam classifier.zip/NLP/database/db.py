"""
SMS Spam Classifier - SQLite Database Manager
Author: B.Tech CSE Capstone Project
Description: Manages database schema, prediction history logging, statistical aggregation,
             and user feedback storage using SQLite.
"""

import os
import json
import sqlite3
import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

DB_PATH = os.path.join(os.path.dirname(__file__), "spam_classifier.db")


def get_connection(db_path: str = DB_PATH) -> sqlite3.Connection:
    """Creates a thread-safe connection to the SQLite database."""
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path: str = DB_PATH):
    """Initializes tables and indices if not present."""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                raw_text TEXT NOT NULL,
                cleaned_text TEXT,
                prediction TEXT NOT NULL,
                confidence REAL NOT NULL,
                spam_probability REAL NOT NULL,
                risk_level TEXT NOT NULL,
                model_used TEXT,
                detected_triggers TEXT,
                has_url INTEGER DEFAULT 0,
                has_phone INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                user_feedback TEXT DEFAULT NULL
            )
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_prediction_created ON predictions(created_at DESC)
        """)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_prediction_label ON predictions(prediction)
        """)
        conn.commit()
    logger.info("SQLite database initialized successfully.")


def save_prediction(data: Dict[str, Any], db_path: str = DB_PATH) -> int:
    """Inserts a new prediction scan record into the database."""
    init_db(db_path)
    heuristics = data.get("explanation", {}).get("heuristics", {})
    triggers = heuristics.get("matched_triggers", [])

    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO predictions (
                raw_text, cleaned_text, prediction, confidence,
                spam_probability, risk_level, model_used,
                detected_triggers, has_url, has_phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.get("raw_text", ""),
            data.get("cleaned_tokens", ""),
            data.get("prediction", "Ham"),
            data.get("confidence", 0.0),
            data.get("spam_probability", 0.0),
            data.get("risk_level", "SAFE"),
            data.get("model_used", "Best Model"),
            json.dumps(triggers),
            1 if heuristics.get("has_url") else 0,
            1 if heuristics.get("has_phone") else 0,
        ))
        conn.commit()
        return cursor.lastrowid


def get_history(
    limit: int = 50,
    offset: int = 0,
    filter_label: Optional[str] = None,
    search_query: Optional[str] = None,
    db_path: str = DB_PATH
) -> List[Dict[str, Any]]:
    """Retrieves paginated prediction history with optional filtering and search."""
    init_db(db_path)
    query = "SELECT * FROM predictions WHERE 1=1"
    params = []

    if filter_label and filter_label.lower() in ["spam", "ham"]:
        query += " AND LOWER(prediction) = ?"
        params.append(filter_label.lower())

    if search_query and search_query.strip():
        query += " AND raw_text LIKE ?"
        params.append(f"%{search_query.strip()}%")

    query += " ORDER BY id DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])

    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute(query, params)
        rows = cursor.fetchall()
        result = []
        for r in rows:
            d = dict(r)
            try:
                d["detected_triggers"] = json.loads(d["detected_triggers"]) if d["detected_triggers"] else []
            except Exception:
                d["detected_triggers"] = []
            result.append(d)
        return result


def get_statistics(db_path: str = DB_PATH) -> Dict[str, Any]:
    """Computes real-time aggregation metrics for the dashboard."""
    init_db(db_path)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()

        # Total counts
        cursor.execute("SELECT COUNT(*) FROM predictions")
        total = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM predictions WHERE prediction = 'Spam'")
        spam_count = cursor.fetchone()[0]

        ham_count = total - spam_count

        # Average confidence
        cursor.execute("SELECT AVG(confidence) FROM predictions")
        avg_conf = cursor.fetchone()[0] or 0.0

        # Heuristic triggers count
        cursor.execute("SELECT SUM(has_url), SUM(has_phone) FROM predictions")
        url_sum, phone_sum = cursor.fetchone()

        return {
            "total_scans": total,
            "spam_scans": spam_count,
            "ham_scans": ham_count,
            "spam_percentage": round((spam_count / total * 100), 1) if total > 0 else 0.0,
            "ham_percentage": round((ham_count / total * 100), 1) if total > 0 else 0.0,
            "avg_confidence": round(float(avg_conf), 2),
            "detected_urls_count": int(url_sum or 0),
            "detected_phones_count": int(phone_sum or 0),
        }


def delete_prediction(pred_id: int, db_path: str = DB_PATH) -> bool:
    """Deletes a specific prediction entry."""
    init_db(db_path)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM predictions WHERE id = ?", (pred_id,))
        conn.commit()
        return cursor.rowcount > 0


def clear_history(db_path: str = DB_PATH) -> bool:
    """Clears all prediction history records."""
    init_db(db_path)
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM predictions")
        conn.commit()
        return True


def update_feedback(pred_id: int, feedback: str, db_path: str = DB_PATH) -> bool:
    """Records user feedback on prediction correctness."""
    init_db(db_path)
    if feedback not in ["correct", "incorrect"]:
        return False
    with get_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE predictions SET user_feedback = ? WHERE id = ?", (feedback, pred_id))
        conn.commit()
        return cursor.rowcount > 0


if __name__ == "__main__":
    init_db()
    stats = get_statistics()
    print("Database statistics:", stats)
