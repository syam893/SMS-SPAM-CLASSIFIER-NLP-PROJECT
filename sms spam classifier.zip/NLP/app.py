"""
SMS Spam Classifier - Flask Web Application & REST API
Author: B.Tech CSE Capstone Project
Description: Full-featured API endpoints and web server connecting ML inference,
             explainability, SQLite persistence, and interactive frontend.
"""

import os
import sys
import json
import logging
from flask import Flask, render_template, request, jsonify, send_from_directory

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from src.predictor import get_predictor
from src.preprocessor import extract_indicators
from database.db import (
    init_db,
    save_prediction,
    get_history,
    get_statistics,
    delete_prediction,
    clear_history,
    update_feedback,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder="static", template_folder="templates")
app.config["SECRET_KEY"] = "btech-nlp-spam-classifier-secure-key-2026"
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024  # 4MB max payload

# Initialize SQLite database
init_db()

# Warm up predictor
predictor = get_predictor()

# Curated sample messages for 1-click testing
SAMPLE_MESSAGES = [
    {
        "category": "Legitimate (Ham)",
        "title": "Casual Friend Chat",
        "text": "Hey, are you free this evening? Let's catch up at the coffee shop near campus around 6.",
    },
    {
        "category": "Legitimate (Ham)",
        "title": "College Project Sync",
        "text": "Hi team, I uploaded the final draft of our project report to Google Drive. Please review section 3 before tomorrow's meeting.",
    },
    {
        "category": "Spam (Financial / Lottery)",
        "title": "Lottery Win Scam",
        "text": "CONGRATULATIONS! Your mobile number won £1,000,000 in the UK National Lottery Draw! Claim your prize now by calling 09061701461. T&C Apply.",
    },
    {
        "category": "Spam (Phishing / Urgent)",
        "title": "Bank Account Suspension Alert",
        "text": "URGENT ALERT: Your Chase Online Banking access is suspended due to unverified transactions. Restore immediately at https://chase-security-verify.net/login or account will close in 24h.",
    },
    {
        "category": "Spam (Free Offer / Promo)",
        "title": "Gift Card & Vouchers",
        "text": "FREE entry! You have been chosen for a $500 Amazon Gift Voucher! Reply WIN or click http://amzn-rewards.pw/redeem now to receive your code.",
    },
]


@app.route("/")
def index():
    """Renders the main single-page dashboard application."""
    return render_template("index.html")


@app.route("/api/predict", methods=["POST"])
def api_predict():
    """Classifies an individual SMS message and persists the result."""
    try:
        data = request.get_json(force=True, silent=True) or {}
        text = data.get("text", "").strip()
        model_name = data.get("model", None)

        if not text:
            return jsonify({"status": "error", "message": "Text input cannot be empty."}), 400

        if len(text) > 2000:
            return jsonify({"status": "error", "message": "Input text exceeds 2000 characters limit."}), 400

        # Perform prediction and explainability analysis
        result = predictor.predict(text, model_name=model_name)

        # Save to SQLite database
        record_id = save_prediction(result)
        result["id"] = record_id
        result["status"] = "success"

        return jsonify(result), 200

    except Exception as e:
        logger.error(f"Prediction error: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/predict-batch", methods=["POST"])
def api_predict_batch():
    """Classifies a list of SMS messages in a single request."""
    try:
        data = request.get_json(force=True, silent=True) or {}
        messages = data.get("messages", [])
        model_name = data.get("model", None)

        if not messages or not isinstance(messages, list):
            return jsonify({"status": "error", "message": "A non-empty list of messages is required."}), 400

        # Limit batch size to 100 messages for responsiveness
        messages = [str(m).strip() for m in messages[:100] if str(m).strip()]
        results = []
        for msg in messages:
            res = predictor.predict(msg, model_name=model_name)
            rec_id = save_prediction(res)
            res["id"] = rec_id
            results.append(res)

        # Compute summary
        total = len(results)
        spam_count = sum(1 for r in results if r["is_spam"])
        ham_count = total - spam_count

        return jsonify({
            "status": "success",
            "batch_summary": {
                "total": total,
                "spam_count": spam_count,
                "ham_count": ham_count,
                "spam_ratio": round((spam_count / total * 100), 2) if total else 0.0,
            },
            "results": results,
        }), 200

    except Exception as e:
        logger.error(f"Batch prediction error: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/history", methods=["GET"])
def api_history():
    """Retrieves paginated scan history."""
    try:
        limit = min(int(request.args.get("limit", 50)), 200)
        offset = max(int(request.args.get("offset", 0)), 0)
        filter_label = request.args.get("filter", None)
        search_query = request.args.get("search", None)

        history = get_history(limit=limit, offset=offset, filter_label=filter_label, search_query=search_query)
        return jsonify({"status": "success", "count": len(history), "history": history}), 200

    except Exception as e:
        logger.error(f"History retrieval error: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/history/<int:pred_id>", methods=["DELETE"])
def api_delete_history(pred_id):
    """Deletes a specific prediction entry."""
    success = delete_prediction(pred_id)
    if success:
        return jsonify({"status": "success", "message": f"Entry {pred_id} deleted."}), 200
    return jsonify({"status": "error", "message": "Entry not found."}), 404


@app.route("/api/history/clear", methods=["DELETE"])
def api_clear_history():
    """Wipes the predictions database table."""
    clear_history()
    return jsonify({"status": "success", "message": "History cleared."}), 200


@app.route("/api/feedback", methods=["POST"])
def api_feedback():
    """Allows user to tag prediction as correct or incorrect."""
    try:
        data = request.get_json(force=True, silent=True) or {}
        pred_id = int(data.get("id", 0))
        feedback = str(data.get("feedback", "")).strip().lower()

        if feedback not in ["correct", "incorrect"]:
            return jsonify({"status": "error", "message": "Invalid feedback value."}), 400

        success = update_feedback(pred_id, feedback)
        return jsonify({"status": "success" if success else "error"}), 200 if success else 404
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/statistics", methods=["GET"])
def api_statistics():
    """Returns database usage statistics combined with benchmark metrics."""
    try:
        db_stats = get_statistics()

        # Load benchmark metrics
        metrics_path = os.path.join("models", "model_metrics.json")
        benchmark_data = {}
        if os.path.exists(metrics_path):
            with open(metrics_path, "r") as f:
                benchmark_data = json.load(f)

        return jsonify({
            "status": "success",
            "database_stats": db_stats,
            "benchmark_data": benchmark_data,
        }), 200

    except Exception as e:
        logger.error(f"Statistics error: {e}", exc_info=True)
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/models", methods=["GET"])
def api_models():
    """Returns list of all available models and their evaluation scores."""
    metrics_path = os.path.join("models", "model_metrics.json")
    if os.path.exists(metrics_path):
        with open(metrics_path, "r") as f:
            data = json.load(f)
        return jsonify({
            "status": "success",
            "best_model": data.get("best_model_name"),
            "models": data.get("models", {}),
        }), 200
    return jsonify({"status": "error", "message": "Models not yet trained."}), 404


@app.route("/api/samples", methods=["GET"])
def api_samples():
    """Returns curated demo messages for quick testing."""
    return jsonify({"status": "success", "samples": SAMPLE_MESSAGES}), 200


@app.errorhandler(404)
def not_found(e):
    return jsonify({"status": "error", "message": "Resource not found"}), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({"status": "error", "message": "Internal server error"}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    logger.info(f"Starting SMS Spam Classifier Web Application on port {port}...")
    app.run(host="127.0.0.1", port=port, debug=False)
