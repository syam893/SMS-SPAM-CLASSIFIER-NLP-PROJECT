"""
SMS Spam Classifier - Application Startup Script
Author: B.Tech CSE Capstone Project
Description: Verifies models and database integrity, then launches the Flask web server.
"""

import os
import sys

# Ensure current directory is in sys.path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from src.train import train_and_evaluate_all
from src.evaluate import ModelEvaluator
from database.db import init_db

def main():
    print("=" * 70)
    print("   ADVANCED NLP-BASED SMS SPAM CLASSIFIER")
    print("   B.Tech Computer Science & Engineering Final Project")
    print("=" * 70)

    # 1. Initialize SQLite Database
    print("[1/3] Initializing SQLite database...")
    init_db()

    # 2. Check if models are trained
    best_model_path = os.path.join("models", "best_model_pipeline.joblib")
    if not os.path.exists(best_model_path):
        print("[2/3] Trained models not found. Running training pipeline (this runs once)...")
        train_and_evaluate_all()
        evaluator = ModelEvaluator()
        evaluator.run_all()
    else:
        print("[2/3] Trained model pipeline verified in models/ directory.")

    # 3. Launch Web Server
    print("[3/3] Launching Flask Web Application & REST API...")
    print("-" * 70)
    print(" Web Interface available at: http://127.0.0.1:5000")
    print(" Press CTRL+C to stop the server.")
    print("-" * 70)

    from app import app
    port = int(os.environ.get("PORT", 5000))
    app.run(host="127.0.0.1", port=port, debug=False)


if __name__ == "__main__":
    main()
