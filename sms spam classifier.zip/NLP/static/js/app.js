/**
 * Advanced NLP SMS Spam Classifier - Frontend Controller
 * Author: B.Tech CSE Capstone Project
 */

// Global State
let currentSamples = [];
let currentPredictionId = null;
let searchTimeout = null;

// DOM Initialization
document.addEventListener("DOMContentLoaded", () => {
    initLucideIcons();
    initTabs();
    initTheme();
    initInputListeners();
    loadPresetSamples();
    loadDashboardStats();
    loadHistory();
});

function initLucideIcons() {
    if (window.lucide) {
        window.lucide.createIcons();
    }
}

// Tab Switching
function initTabs() {
    const navTabs = document.querySelectorAll(".nav-tab");
    navTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            const targetId = tab.getAttribute("data-tab");
            navTabs.forEach(t => t.classList.remove("active"));
            document.querySelectorAll(".tab-pane").forEach(pane => pane.classList.remove("active"));

            tab.classList.add("active");
            const targetPane = document.getElementById(targetId);
            if (targetPane) targetPane.classList.add("active");
            initLucideIcons();
        });
    });
}

// Light / Dark Theme Toggle
function initTheme() {
    const themeBtn = document.getElementById("theme-toggle");
    const savedTheme = localStorage.getItem("spamguard_theme") || "dark";
    if (savedTheme === "light") {
        document.body.classList.remove("dark-theme");
        document.body.classList.add("light-theme");
        themeBtn.innerHTML = '<i data-lucide="moon"></i>';
    }

    themeBtn.addEventListener("click", () => {
        if (document.body.classList.contains("light-theme")) {
            document.body.classList.remove("light-theme");
            document.body.classList.add("dark-theme");
            localStorage.setItem("spamguard_theme", "dark");
            themeBtn.innerHTML = '<i data-lucide="sun"></i>';
        } else {
            document.body.classList.remove("dark-theme");
            document.body.classList.add("light-theme");
            localStorage.setItem("spamguard_theme", "light");
            themeBtn.innerHTML = '<i data-lucide="moon"></i>';
        }
        initLucideIcons();
    });
}

// Input Listeners & Character Counter
function initInputListeners() {
    const smsInput = document.getElementById("sms-input");
    const charCounter = document.getElementById("char-counter");
    const btnPredict = document.getElementById("btn-predict");
    const btnClear = document.getElementById("btn-clear-input");
    const btnRandom = document.getElementById("btn-random-sample");

    smsInput.addEventListener("input", () => {
        const len = smsInput.value.length;
        charCounter.textContent = `${len} / 2000 characters`;
    });

    btnClear.addEventListener("click", () => {
        smsInput.value = "";
        charCounter.textContent = "0 / 2000 characters";
        smsInput.focus();
    });

    btnPredict.addEventListener("click", runPrediction);

    btnRandom.addEventListener("click", () => {
        if (currentSamples.length > 0) {
            const randIdx = Math.floor(Math.random() * currentSamples.length);
            loadSample(randIdx);
        }
    });

    // Enter + Ctrl/Cmd shortcut
    smsInput.addEventListener("keydown", (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
            runPrediction();
        }
    });
}

// Load Preset Samples from Server
async function loadPresetSamples() {
    try {
        const res = await fetch("/api/samples");
        const data = await res.json();
        if (data.status === "success") {
            currentSamples = data.samples;
        }
    } catch (err) {
        console.warn("Could not load samples:", err);
    }
}

function loadSample(index) {
    if (currentSamples && currentSamples[index]) {
        const smsInput = document.getElementById("sms-input");
        smsInput.value = currentSamples[index].text;
        document.getElementById("char-counter").textContent = `${smsInput.value.length} / 2000 characters`;
        runPrediction();
    }
}

// Main Prediction Logic
async function runPrediction() {
    const smsInput = document.getElementById("sms-input");
    const text = smsInput.value.trim();
    const modelSelector = document.getElementById("model-selector");
    const selectedModel = modelSelector.value || null;

    if (!text) {
        alert("Please enter or paste an SMS message to classify.");
        smsInput.focus();
        return;
    }

    const btnPredict = document.getElementById("btn-predict");
    const originalBtnHtml = btnPredict.innerHTML;
    btnPredict.disabled = true;
    btnPredict.innerHTML = '<i data-lucide="loader" class="spin"></i> Classifying...';
    initLucideIcons();

    try {
        const response = await fetch("/api/predict", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: text, model: selectedModel })
        });

        const data = await response.json();

        if (response.ok && data.status === "success") {
            renderPredictionResult(data);
            loadDashboardStats();
            loadHistory();
        } else {
            alert("Prediction failed: " + (data.message || "Unknown error"));
        }
    } catch (err) {
        console.error("Prediction request failed:", err);
        alert("Error connecting to server. Ensure Flask backend is running.");
    } finally {
        btnPredict.disabled = false;
        btnPredict.innerHTML = originalBtnHtml;
        initLucideIcons();
    }
}

// Render Prediction Result
function renderPredictionResult(data) {
    currentPredictionId = data.id;
    document.getElementById("result-placeholder").classList.add("hidden");
    const content = document.getElementById("result-content");
    content.classList.remove("hidden");

    // Scan ID Tag
    document.getElementById("scan-id-tag").textContent = `Scan #${data.id} (${data.model_used})`;

    // Verdict Banner
    const banner = document.getElementById("verdict-banner");
    const label = document.getElementById("verdict-label");
    const riskBadge = document.getElementById("risk-badge");
    const confVal = document.getElementById("confidence-val");

    banner.classList.remove("is-spam", "is-ham");
    if (data.is_spam) {
        banner.classList.add("is-spam");
        label.textContent = "SPAM DETECTED";
    } else {
        banner.classList.add("is-ham");
        label.textContent = "HAM (LEGITIMATE)";
    }

    riskBadge.textContent = data.risk_level;
    riskBadge.style.backgroundColor = data.risk_color;
    riskBadge.style.color = "#ffffff";
    confVal.textContent = `${data.confidence}%`;

    // Probability Meter
    document.getElementById("prob-ham-text").textContent = `${data.ham_probability}%`;
    document.getElementById("prob-spam-text").textContent = `${data.spam_probability}%`;
    const spamFill = document.getElementById("meter-fill-spam");
    spamFill.style.width = `${data.spam_probability}%`;

    // Heuristics
    const h = data.explanation.heuristics;
    document.getElementById("val-h-url").textContent = h.has_url ? (h.detected_urls[0] || "Detected") : "None";
    document.getElementById("val-h-phone").textContent = h.has_phone ? (h.detected_phones[0] || "Detected") : "None";
    document.getElementById("val-h-currency").textContent = h.has_currency ? (h.detected_currencies[0] || "Detected") : "None";
    document.getElementById("val-h-caps").textContent = `${Math.round(h.caps_ratio * 100)}%`;

    // Triggers
    const triggersContainer = document.getElementById("triggers-chips");
    triggersContainer.innerHTML = "";
    if (h.matched_triggers && h.matched_triggers.length > 0) {
        h.matched_triggers.forEach(word => {
            const chip = document.createElement("span");
            chip.className = "t-chip";
            chip.textContent = word;
            triggersContainer.appendChild(chip);
        });
    } else {
        triggersContainer.innerHTML = '<span style="color: var(--text-muted); font-size: 0.8rem;">None detected</span>';
    }

    // Token Attribution Pills (XAI)
    const tokenContainer = document.getElementById("token-pills");
    tokenContainer.innerHTML = "";
    const attributions = data.explanation.all_attributions || [];

    if (attributions.length > 0) {
        attributions.forEach(item => {
            const pill = document.createElement("span");
            const impactClass = item.impact === "spam" ? "token-spam" : (item.impact === "ham" ? "token-ham" : "token-neutral");
            pill.className = `token-pill ${impactClass}`;
            pill.innerHTML = `${item.token} <span class="token-weight">${item.contribution > 0 ? "+" : ""}${item.contribution}</span>`;
            tokenContainer.appendChild(pill);
        });
    } else {
        tokenContainer.innerHTML = '<span style="color: var(--text-muted); font-size: 0.8rem;">No influential vocabulary tokens detected.</span>';
    }

    // Reasons List
    const reasonsList = document.getElementById("reasons-list");
    reasonsList.innerHTML = "";
    (data.explanation.reasons || []).forEach(r => {
        const li = document.createElement("li");
        li.textContent = r;
        reasonsList.appendChild(li);
    });

    initLucideIcons();
}

// User Feedback (Correct/Incorrect)
async function sendFeedback(type) {
    if (!currentPredictionId) return;
    try {
        const res = await fetch("/api/feedback", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: currentPredictionId, feedback: type })
        });
        const d = await res.json();
        if (d.status === "success") {
            alert(`Thank you! Recorded feedback as: ${type}`);
            loadHistory();
        }
    } catch (e) {
        console.error(e);
    }
}

// Dashboard Quick Stats
async function loadDashboardStats() {
    try {
        const res = await fetch("/api/statistics");
        const data = await res.json();
        if (data.status === "success") {
            const db = data.database_stats;
            document.getElementById("stat-total-scans").textContent = db.total_scans;

            const bm = data.benchmark_data;
            if (bm && bm.dataset_statistics) {
                document.getElementById("stat-records").textContent = `${bm.dataset_statistics.final_clean_records.toLocaleString()} Cleaned`;
            }
            if (bm && bm.models && bm.best_model_name) {
                const best = bm.models[bm.best_model_name];
                document.getElementById("stat-accuracy").textContent = `${(best.test_accuracy * 100).toFixed(1)}%`;
                document.getElementById("nav-champion-model").textContent = `${bm.best_model_name} (${(best.test_accuracy * 100).toFixed(1)}%)`;
            }
        }
    } catch (err) {
        console.warn("Stats load failed:", err);
    }
}

// Batch Scanner
function loadBatchSample() {
    const sampleBatch = [
        "Hey bro, are we still meeting at the library at 5pm? Let me know.",
        "URGENT! You have won a 1 week FREE holiday to Hawaii. Call 09061701461 now to claim your prize! T&C apply.",
        "Your Chase Bank account is temporarily locked due to suspicious activity. Verify immediately at http://secure-chase-update.com/login",
        "Your Amazon delivery package #49281 has arrived. Thanks for ordering with us.",
        "CLAIM £500 CASH or $1000 gift voucher immediately! Reply WIN to 88088 now."
    ];
    document.getElementById("batch-input").value = sampleBatch.join("\n");
}

async function runBatchPredict() {
    const raw = document.getElementById("batch-input").value.trim();
    if (!raw) {
        alert("Please enter messages to batch scan.");
        return;
    }
    const lines = raw.split("\n").map(l => l.trim()).filter(l => l.length > 0);
    const btn = document.getElementById("btn-batch-predict");
    btn.disabled = true;
    btn.innerHTML = '<i data-lucide="loader" class="spin"></i> Processing Batch...';

    try {
        const res = await fetch("/api/predict-batch", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ messages: lines })
        });
        const data = await res.json();
        if (data.status === "success") {
            const summary = data.batch_summary;
            document.getElementById("batch-summary").style.display = "block";
            document.getElementById("batch-total").textContent = summary.total;
            document.getElementById("batch-spam").textContent = summary.spam_count;
            document.getElementById("batch-ham").textContent = summary.ham_count;
            document.getElementById("batch-ratio").textContent = `${summary.spam_ratio}%`;

            const tbody = document.getElementById("batch-table-body");
            tbody.innerHTML = "";
            data.results.forEach((r, idx) => {
                const tr = document.createElement("tr");
                const tagClass = r.is_spam ? "spam" : "ham";
                tr.innerHTML = `
                    <td>${idx + 1}</td>
                    <td>${r.raw_text.substring(0, 70)}${r.raw_text.length > 70 ? "..." : ""}</td>
                    <td><span class="verdict-tag ${tagClass}">${r.prediction}</span></td>
                    <td>${r.confidence}%</td>
                    <td><span style="color: ${r.risk_color}; font-weight: 600;">${r.risk_level}</span></td>
                `;
                tbody.appendChild(tr);
            });
            loadDashboardStats();
            loadHistory();
        }
    } catch (e) {
        alert("Batch processing error: " + e);
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i data-lucide="play"></i> Run Batch Classification';
        initLucideIcons();
    }
}

// Scan History Functions
function debounceHistorySearch() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(loadHistory, 350);
}

async function loadHistory() {
    const filter = document.getElementById("history-filter")?.value || "";
    const search = document.getElementById("history-search")?.value || "";

    let url = `/api/history?limit=50`;
    if (filter) url += `&filter=${filter}`;
    if (search) url += `&search=${encodeURIComponent(search)}`;

    try {
        const res = await fetch(url);
        const data = await res.json();
        if (data.status !== "success") return;

        const tbody = document.getElementById("history-table-body");
        if (!tbody) return;
        tbody.innerHTML = "";

        if (data.history.length === 0) {
            tbody.innerHTML = `<tr><td colspan="9" style="text-align: center; color: var(--text-muted); padding: 2rem;">No scan history found.</td></tr>`;
            return;
        }

        data.history.forEach(item => {
            const tr = document.createElement("tr");
            const tagClass = item.prediction.toLowerCase() === "spam" ? "spam" : "ham";
            const triggers = item.detected_triggers || [];
            const triggersHtml = triggers.length > 0
                ? triggers.map(t => `<span class="t-chip">${t}</span>`).join(" ")
                : '<span style="color: var(--text-muted); font-size: 0.75rem;">None</span>';

            const feedbackHtml = item.user_feedback
                ? `<span style="font-size: 0.78rem; font-weight: 600; color: ${item.user_feedback === 'correct' ? '#10b981' : '#ef4444'}">${item.user_feedback}</span>`
                : '<span style="color: var(--text-muted); font-size: 0.75rem;">Unrated</span>';

            tr.innerHTML = `
                <td>#${item.id}</td>
                <td style="font-size: 0.78rem; white-space: nowrap;">${item.created_at}</td>
                <td style="max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.raw_text}">${item.raw_text}</td>
                <td><span class="verdict-tag ${tagClass}">${item.prediction}</span></td>
                <td><strong>${item.confidence.toFixed(1)}%</strong></td>
                <td><span style="font-size: 0.78rem; font-weight: 600;">${item.risk_level}</span></td>
                <td><div style="display: flex; flex-wrap: wrap; gap: 3px;">${triggersHtml}</div></td>
                <td>${feedbackHtml}</td>
                <td>
                    <button class="btn-icon" style="width: 28px; height: 28px;" onclick="deleteHistoryItem(${item.id})" title="Delete entry">
                        <i data-lucide="trash-2" style="width: 14px; height: 14px; color: #f87171;"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
        initLucideIcons();
    } catch (err) {
        console.error("Failed to load history:", err);
    }
}

async function deleteHistoryItem(id) {
    if (!confirm(`Delete history record #${id}?`)) return;
    try {
        const res = await fetch(`/api/history/${id}`, { method: "DELETE" });
        if (res.ok) {
            loadHistory();
            loadDashboardStats();
        }
    } catch (e) {
        console.error(e);
    }
}

async function confirmClearHistory() {
    if (!confirm("Are you sure you want to permanently clear all scan history from the SQLite database?")) return;
    try {
        const res = await fetch("/api/history/clear", { method: "DELETE" });
        if (res.ok) {
            loadHistory();
            loadDashboardStats();
        }
    } catch (e) {
        console.error(e);
    }
}

