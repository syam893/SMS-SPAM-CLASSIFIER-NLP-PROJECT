"""
SMS Spam Classifier - Feature Engineering Module
Author: B.Tech CSE Capstone Project
Description: Implements TF-IDF vectorization, Bag-of-Words, n-grams, statistical
             and linguistic feature extraction, and feature combination pipelines.
"""

import os
import sys

# Ensure project root is available in module path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Union
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.preprocessing import StandardScaler
from scipy.sparse import hstack, issparse, csr_matrix

from src.preprocessor import extract_indicators, TextPreprocessor


class StatisticalFeatureExtractor(BaseEstimator, TransformerMixin):
    """
    Extracts numerical linguistic and statistical metadata features from raw text:
    - Character count
    - Word count
    - Uppercase ratio
    - Digit ratio
    - Exclamation mark count
    - URL presence (0 or 1)
    - Phone number presence (0 or 1)
    - Currency symbol presence (0 or 1)
    - Trigger keyword count
    - Heuristic risk score
    """

    FEATURE_NAMES = [
        "char_count",
        "word_count",
        "caps_ratio",
        "digit_ratio",
        "exclamation_count",
        "has_url",
        "has_phone",
        "has_currency",
        "trigger_count",
        "heuristic_risk_score",
    ]

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        if hasattr(X, "tolist"):
            X = X.tolist()
        features = []
        for text in X:
            ind = extract_indicators(text)
            features.append([
                float(ind["char_count"]),
                float(ind["word_count"]),
                float(ind["caps_ratio"]),
                float(ind["digit_ratio"]),
                float(ind["exclamation_count"]),
                1.0 if ind["has_url"] else 0.0,
                1.0 if ind["has_phone"] else 0.0,
                1.0 if ind["has_currency"] else 0.0,
                float(len(ind["matched_triggers"])),
                float(ind["heuristic_risk_score"]) / 100.0,
            ])
        return np.array(features, dtype=np.float32)

    def get_feature_names_out(self, input_features=None):
        return np.array(self.FEATURE_NAMES)


def build_tfidf_vectorizer(
    max_features: int = 4000,
    ngram_range: tuple = (1, 2),
    min_df: int = 2,
    sublinear_tf: bool = True,
) -> TfidfVectorizer:
    """Creates a configured TF-IDF vectorizer."""
    return TfidfVectorizer(
        max_features=max_features,
        ngram_range=ngram_range,
        min_df=min_df,
        sublinear_tf=sublinear_tf,
    )


def build_bow_vectorizer(
    max_features: int = 4000,
    ngram_range: tuple = (1, 2),
    min_df: int = 2,
) -> CountVectorizer:
    """Creates a configured Bag-of-Words (Count) vectorizer."""
    return CountVectorizer(
        max_features=max_features,
        ngram_range=ngram_range,
        min_df=min_df,
    )


class DenseTransformer(BaseEstimator, TransformerMixin):
    """Converts sparse matrices to dense arrays if needed by certain classifiers."""
    def fit(self, X, y=None):
        return self
    def transform(self, X):
        if issparse(X):
            return X.toarray()
        return X


if __name__ == "__main__":
    texts = [
        "Hey, are we still meeting for lunch at 1pm?",
        "URGENT! You won $5000 prize. Call 0800998877 now or click http://claim-award.com",
    ]
    extractor = StatisticalFeatureExtractor()
    feat = extractor.transform(texts)
    print("Statistical features shape:", feat.shape)
    for col, val in zip(StatisticalFeatureExtractor.FEATURE_NAMES, feat[1]):
        print(f"  {col}: {val}")
