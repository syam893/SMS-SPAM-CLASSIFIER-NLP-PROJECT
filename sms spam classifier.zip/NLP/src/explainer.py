"""
SMS Spam Classifier - Model Explainability Module
Author: B.Tech CSE Capstone Project
Description: Computes local token-level feature attribution and heuristic explanations
             for individual SMS predictions to make the model transparent and interpretable.
"""

import os
import sys
import json
import logging
import numpy as np

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.preprocessor import extract_indicators, TextPreprocessor

logger = logging.getLogger(__name__)


class SpamExplainer:
    """Explains predictions using model coefficients, token attribution, and rule heuristics."""

    def __init__(self, pipeline, model_name: str = "Logistic Regression"):
        self.pipeline = pipeline
        self.model_name = model_name
        self.preprocessor = TextPreprocessor(method="lemma", remove_stopwords=True)

        # Inspect pipeline components
        self.tfidf = self.pipeline.named_steps.get("tfidf")
        self.classifier = self.pipeline.named_steps.get("classifier")

        # Extract vocabulary and coefficients if linear model
        self.vocab = self.tfidf.vocabulary_ if self.tfidf else {}
        self.feature_names = self.tfidf.get_feature_names_out() if self.tfidf else []

        self.weights = None
        if hasattr(self.classifier, "coef_"):
            self.weights = self.classifier.coef_[0]
        elif hasattr(self.classifier, "feature_log_prob_"):
            # For Naive Bayes, log prob difference: log P(w|Spam) - log P(w|Ham)
            self.weights = self.classifier.feature_log_prob_[1] - self.classifier.feature_log_prob_[0]
        elif hasattr(self.classifier, "calibrated_classifiers_"):
            # For CalibratedClassifierCV wrapping LinearSVC
            base_clf = self.classifier.calibrated_classifiers_[0].estimator
            if hasattr(base_clf, "coef_"):
                self.weights = base_clf.coef_[0]

    def explain_message(self, text: str, spam_prob: float, prediction: str) -> dict:
        """
        Analyzes tokens and heuristics in a message and returns structured explainability data.
        """
        heuristics = extract_indicators(text)
        cleaned_text = self.preprocessor.preprocess(text)
        tokens = cleaned_text.split()

        word_attributions = []
        spam_contributors = []
        ham_contributors = []

        if self.weights is not None and self.vocab:
            # Transform text through TF-IDF to get exact weights for this document
            tfidf_vec = self.tfidf.transform([cleaned_text])
            feature_indices = tfidf_vec.nonzero()[1]

            for idx in feature_indices:
                word = self.feature_names[idx]
                tfidf_val = tfidf_vec[0, idx]
                coef_val = self.weights[idx]
                contribution = float(tfidf_val * coef_val)

                entry = {
                    "token": word,
                    "contribution": round(contribution, 4),
                    "impact": "spam" if contribution > 0.05 else ("ham" if contribution < -0.05 else "neutral"),
                }
                word_attributions.append(entry)
                if contribution > 0.05:
                    spam_contributors.append(entry)
                elif contribution < -0.05:
                    ham_contributors.append(entry)

        # Sort by magnitude of contribution
        spam_contributors = sorted(spam_contributors, key=lambda x: x["contribution"], reverse=True)
        ham_contributors = sorted(ham_contributors, key=lambda x: x["contribution"])

        # Construct clear natural language reasoning
        reasons = []
        if prediction == "Spam":
            if heuristics["has_url"]:
                reasons.append("Contains suspicious external hyperlink(s).")
            if heuristics["has_phone"]:
                reasons.append("Directs recipient to call a toll/mobile number.")
            if heuristics["has_currency"]:
                reasons.append("References financial sums or currency prizes.")
            if heuristics["caps_ratio"] > 0.25:
                reasons.append(f"Unusually high uppercase letter ratio ({heuristics['caps_ratio']*100:.1f}%).")
            if spam_contributors:
                top_words = [f"'{w['token']}'" for w in spam_contributors[:4]]
                reasons.append(f"High-frequency spam vocabulary detected: {', '.join(top_words)}.")
            if not reasons:
                reasons.append("Linguistic patterns strongly align with known unsolicited advertising templates.")
        else:
            if ham_contributors:
                top_words = [f"'{w['token']}'" for w in ham_contributors[:3]]
                reasons.append(f"Contains personal/conversational words: {', '.join(top_words)}.")
            reasons.append("No predatory links, phone prompts, or lottery trigger phrases detected.")

        return {
            "prediction": prediction,
            "spam_probability": round(spam_prob, 4),
            "ham_probability": round(1.0 - spam_prob, 4),
            "heuristic_risk_score": heuristics["heuristic_risk_score"],
            "reasons": reasons,
            "top_spam_words": spam_contributors[:6],
            "top_ham_words": ham_contributors[:6],
            "all_attributions": word_attributions,
            "heuristics": heuristics,
        }


if __name__ == "__main__":
    import joblib
    model_path = "models/best_model_pipeline.joblib"
    if os.path.exists(model_path):
        pipe = joblib.load(model_path)
        explainer = SpamExplainer(pipe)
        exp = explainer.explain_message("Free entry in 2 a weekly comp to win £1000 cash! Call 09064018831", 0.98, "Spam")
        print("Reasons:", exp["reasons"])
        print("Spam tokens:", exp["top_spam_words"])
