"""
SMS Spam Classifier - NLP Preprocessing Pipeline
Author: B.Tech CSE Capstone Project
Description: Comprehensive text preprocessing including normalization, tokenization,
             stopword removal, stemming, lemmatization, and metadata/indicator extraction.
"""

import re
import string
import logging
from typing import List, Dict, Any, Tuple
import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer
from sklearn.base import BaseEstimator, TransformerMixin

logger = logging.getLogger(__name__)

# Ensure NLTK resources are available
try:
    STOPWORDS = set(stopwords.words("english"))
except LookupError:
    nltk.download("stopwords", quiet=True)
    STOPWORDS = set(stopwords.words("english"))

try:
    LEMMATIZER = WordNetLemmatizer()
    LEMMATIZER.lemmatize("testing")
except Exception:
    nltk.download("wordnet", quiet=True)
    nltk.download("omw-1.4", quiet=True)
    LEMMATIZER = WordNetLemmatizer()

STEMMER = PorterStemmer()

# Contraction mapping for text normalization
CONTRACTIONS = {
    "won't": "will not",
    "can't": "cannot",
    "n't": " not",
    "'re": " are",
    "'s": " is",
    "'d": " would",
    "'ll": " will",
    "'t": " not",
    "'ve": " have",
    "'m": " am",
    "u": "you",
    "ur": "your",
    "r": "are",
    "txt": "text",
    "msg": "message",
    "pls": "please",
    "plz": "please",
    "2": "to",
    "4": "for",
    "b4": "before",
}

# Regex patterns for high-signal entities
URL_PATTERN = re.compile(r"https?://\S+|www\.\S+|[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:/\S*)?", re.IGNORECASE)
EMAIL_PATTERN = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b")
PHONE_PATTERN = re.compile(r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{3,5}\)?[-.\s]?\d{3,5}[-.\s]?\d{3,5}|\b\d{5,12}\b")
CURRENCY_PATTERN = re.compile(r"[\$£€¥₹]|(?:Rs\.?|INR|USD|GBP|EUR)\s*\d+", re.IGNORECASE)

# High-frequency urgency / spam trigger keywords
SPAM_TRIGGER_WORDS = {
    "free", "win", "winner", "won", "prize", "cash", "claim", "urgent", "call", "now",
    "congrats", "congratulations", "guaranteed", "selected", "entry", "draw", "award",
    "bonus", "credit", "loan", "gift", "voucher", "expire", "immediate", "action",
    "verify", "password", "bank", "account", "suspended", "security", "alert", "otp",
    "refund", "bitcoin", "crypto", "dating", "subscribe", "sub", "unsub", "stop"
}


def expand_contractions(text: str) -> str:
    """Expands common informal contractions and SMS shortforms."""
    for cont, expanded in CONTRACTIONS.items():
        text = re.sub(r"\b" + re.escape(cont) + r"\b", expanded, text, flags=re.IGNORECASE)
    return text


def extract_indicators(text: str) -> Dict[str, Any]:
    """
    Extracts security and spam-indicative heuristic features from raw text.
    Used for rule-based flags and model explainability.
    """
    if not isinstance(text, str):
        text = str(text)

    char_count = len(text)
    words = text.split()
    word_count = len(words)

    # Uppercase analysis
    caps_count = sum(1 for c in text if c.isupper())
    caps_ratio = round(caps_count / max(char_count, 1), 4)

    # Digits and special characters
    digit_count = sum(1 for c in text if c.isdigit())
    digit_ratio = round(digit_count / max(char_count, 1), 4)
    excl_count = text.count("!")
    question_count = text.count("?")

    # Entity detection
    urls = URL_PATTERN.findall(text)
    emails = EMAIL_PATTERN.findall(text)
    phones = [p for p in PHONE_PATTERN.findall(text) if len(re.sub(r"\D", "", p)) >= 5]
    currencies = CURRENCY_PATTERN.findall(text)

    # Trigger words matched
    lower_words = re.findall(r"\b[a-z]+\b", text.lower())
    matched_triggers = sorted(list(SPAM_TRIGGER_WORDS.intersection(set(lower_words))))

    # Compute rule-based risk score (0 to 100)
    risk_score = 0
    if urls:
        risk_score += 30
    if phones:
        risk_score += 25
    if currencies:
        risk_score += 20
    if matched_triggers:
        risk_score += min(len(matched_triggers) * 10, 30)
    if caps_ratio > 0.3:
        risk_score += 15
    if excl_count >= 2:
        risk_score += 10
    risk_score = min(risk_score, 100)

    return {
        "char_count": char_count,
        "word_count": word_count,
        "caps_count": caps_count,
        "caps_ratio": caps_ratio,
        "digit_count": digit_count,
        "digit_ratio": digit_ratio,
        "exclamation_count": excl_count,
        "question_count": question_count,
        "has_url": bool(urls),
        "detected_urls": urls[:3],
        "has_email": bool(emails),
        "detected_emails": emails[:3],
        "has_phone": bool(phones),
        "detected_phones": phones[:3],
        "has_currency": bool(currencies),
        "detected_currencies": currencies[:3],
        "matched_triggers": matched_triggers,
        "heuristic_risk_score": risk_score,
    }


class TextPreprocessor:
    """
    Modular NLP text preprocessor with configurable stemming or lemmatization,
    stopwords filtering, and entity token masking.
    """

    def __init__(
        self,
        method: str = "lemma",  # 'lemma', 'stem', or 'none'
        remove_stopwords: bool = True,
        mask_entities: bool = True,
        lowercase: bool = True,
    ):
        self.method = method
        self.remove_stopwords = remove_stopwords
        self.mask_entities = mask_entities
        self.lowercase = lowercase
        self.stopwords = STOPWORDS
        self.stemmer = STEMMER
        self.lemmatizer = LEMMATIZER

    def preprocess(self, text: str) -> str:
        """Transforms a raw message into a clean, normalized token string."""
        if not isinstance(text, str):
            text = str(text)

        # 1. Lowercase if required
        if self.lowercase:
            text = text.lower()

        # 2. Expand contractions
        text = expand_contractions(text)

        # 3. Entity masking / tokenization
        if self.mask_entities:
            text = URL_PATTERN.sub(" url_token ", text)
            text = EMAIL_PATTERN.sub(" email_token ", text)
            text = PHONE_PATTERN.sub(" phone_token ", text)
            text = CURRENCY_PATTERN.sub(" currency_token ", text)

        # 4. Remove punctuation and special symbols
        text = re.sub(r"[^\w\s]", " ", text)

        # 5. Tokenize via regex (handles alphanumeric and tokens cleanly)
        tokens = re.findall(r"\b[a-zA-Z_]{2,}\b", text)

        # 6. Stopwords removal
        if self.remove_stopwords:
            tokens = [t for t in tokens if t not in self.stopwords]

        # 7. Stemming or Lemmatization
        if self.method == "lemma":
            tokens = [self.lemmatizer.lemmatize(t) for t in tokens]
        elif self.method == "stem":
            tokens = [self.stemmer.stem(t) for t in tokens]

        return " ".join(tokens)

    def transform_series(self, series: List[str]) -> List[str]:
        """Preprocesses an entire list or pandas Series of texts."""
        return [self.preprocess(text) for text in series]


class SklearnTextPreprocessor(BaseEstimator, TransformerMixin):
    """Scikit-Learn compatible transformer wrapper for Pipeline integration."""

    def __init__(self, method="lemma", remove_stopwords=True, mask_entities=True):
        self.method = method
        self.remove_stopwords = remove_stopwords
        self.mask_entities = mask_entities
        self.preprocessor = TextPreprocessor(
            method=self.method,
            remove_stopwords=self.remove_stopwords,
            mask_entities=self.mask_entities,
        )

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        if hasattr(X, "tolist"):
            X = X.tolist()
        return [self.preprocessor.preprocess(x) for x in X]


if __name__ == "__main__":
    sample = "CONGRATS! You won $1000 cash or a free gift card. Call 0800123456 now or visit www.win-prize.com! won't last!"
    pre = TextPreprocessor(method="lemma")
    clean = pre.preprocess(sample)
    ind = extract_indicators(sample)
    print("Original:", sample)
    print("Preprocessed:", clean)
    print("\nExtracted Indicators:")
    for k, v in ind.items():
        print(f"  {k}: {v}")
