"""
SMS Spam Classifier - Model Training & Benchmark Pipeline
Author: B.Tech CSE Capstone Project
Description: Trains and compares MultinomialNB, Logistic Regression, Linear SVM (calibrated),
             and Random Forest on strictly stratified splits without data leakage.
"""

import os
import sys
import json
import logging
import joblib
import numpy as np
import pandas as pd

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)

from src.data_loader import DatasetManager
from src.preprocessor import SklearnTextPreprocessor, TextPreprocessor
from src.feature_engineering import build_tfidf_vectorizer

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def train_and_evaluate_all(models_dir: str = "models"):
    """
    Executes end-to-end model training, 5-fold cross-validation, test set evaluation,
    and serialization of models and metrics.
    """
    os.makedirs(models_dir, exist_ok=True)

    # 1. Dataset loading and stratified splitting
    logger.info("Step 1: Loading dataset and preparing stratified train/test split...")
    dataset_mgr = DatasetManager()
    X_train_raw, X_test_raw, y_train, y_test, dataset_stats = dataset_mgr.get_train_test_split(
        test_size=0.2, random_state=42, remove_duplicates=True
    )

    # 2. Define Candidate Models
    # Note: LinearSVC is wrapped in CalibratedClassifierCV (isotonic/sigmoid)
    # to provide valid posterior probability estimates (predict_proba).
    candidate_algorithms = {
        "Multinomial Naive Bayes": MultinomialNB(alpha=0.2),
        "Logistic Regression": LogisticRegression(C=2.0, max_iter=1000, random_state=42),
        "Support Vector Machine": CalibratedClassifierCV(
            LinearSVC(C=1.0, random_state=42, dual=False), cv=3
        ),
        "Random Forest": RandomForestClassifier(
            n_estimators=150, max_depth=None, random_state=42, n_jobs=-1
        ),
    }

    results = {}
    trained_pipelines = {}
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    logger.info("\nStep 2: Training and cross-validating candidate models (No data leakage)...")

    for name, clf in candidate_algorithms.items():
        logger.info(f"\n--- Training {name} ---")

        # Create end-to-end pipeline: TextPreprocessor -> TF-IDF Vectorizer -> Classifier
        pipeline = Pipeline([
            ("preprocessor", SklearnTextPreprocessor(method="lemma", remove_stopwords=True)),
            ("tfidf", build_tfidf_vectorizer(max_features=4000, ngram_range=(1, 2))),
            ("classifier", clf),
        ])

        # 5-Fold Stratified Cross Validation on Training set ONLY
        logger.info(f"Running 5-fold cross-validation for {name} on training partition...")
        cv_scores = cross_val_score(pipeline, X_train_raw, y_train, cv=cv, scoring="f1", n_jobs=-1)
        mean_cv_f1 = float(np.mean(cv_scores))
        std_cv_f1 = float(np.std(cv_scores))
        logger.info(f"{name} 5-Fold CV F1-Score: {mean_cv_f1:.4f} (+/- {std_cv_f1:.4f})")

        # Fit final pipeline on full training set
        pipeline.fit(X_train_raw, y_train)
        trained_pipelines[name] = pipeline

        # Predict on unseen test set
        y_pred = pipeline.predict(X_test_raw)
        y_prob = pipeline.predict_proba(X_test_raw)[:, 1]

        acc = float(accuracy_score(y_test, y_pred))
        prec = float(precision_score(y_test, y_pred, zero_division=0))
        rec = float(recall_score(y_test, y_pred, zero_division=0))
        f1 = float(f1_score(y_test, y_pred, zero_division=0))
        auc = float(roc_auc_score(y_test, y_prob))
        cm = confusion_matrix(y_test, y_pred).tolist()

        logger.info(f"Test Set Results for {name}:")
        logger.info(f"  Accuracy:  {acc * 100:.2f}%")
        logger.info(f"  Precision: {prec * 100:.2f}%")
        logger.info(f"  Recall:    {rec * 100:.2f}%")
        logger.info(f"  F1-Score:  {f1 * 100:.2f}%")
        logger.info(f"  ROC-AUC:   {auc:.4f}")
        logger.info(f"  Confusion Matrix: TN={cm[0][0]}, FP={cm[0][1]}, FN={cm[1][0]}, TP={cm[1][1]}")

        results[name] = {
            "name": name,
            "cv_f1_mean": round(mean_cv_f1, 4),
            "cv_f1_std": round(std_cv_f1, 4),
            "test_accuracy": round(acc, 4),
            "test_precision": round(prec, 4),
            "test_recall": round(rec, 4),
            "test_f1": round(f1, 4),
            "test_roc_auc": round(auc, 4),
            "confusion_matrix": cm,
            "classification_report": classification_report(y_test, y_pred, output_dict=True),
        }

    # 3. Determine the Best Model
    # We rank primarily by F1-Score (balances precision and recall on imbalanced SMS data),
    # with ROC-AUC as secondary metric.
    best_model_name = max(results.keys(), key=lambda k: (results[k]["test_f1"], results[k]["test_roc_auc"]))
    best_pipeline = trained_pipelines[best_model_name]
    logger.info(f"\n>>> Best Overall Model Selected: '{best_model_name}' (F1: {results[best_model_name]['test_f1']}) <<<")

    # 4. Extract Top Indicative Vocabulary Words for Explainability
    logger.info("Extracting top vocabulary features from Logistic Regression / Naive Bayes...")
    lr_pipeline = trained_pipelines["Logistic Regression"]
    tfidf_vectorizer = lr_pipeline.named_steps["tfidf"]
    feature_names = tfidf_vectorizer.get_feature_names_out()
    lr_clf = lr_pipeline.named_steps["classifier"]
    coefficients = lr_clf.coef_[0]

    # Sort coefficients: highest positive = strong spam indicators, lowest negative = strong ham indicators
    top_spam_indices = np.argsort(coefficients)[-30:][::-1]
    top_ham_indices = np.argsort(coefficients)[:30]

    top_spam_features = [
        {"word": feature_names[i], "weight": round(float(coefficients[i]), 4)}
        for i in top_spam_indices
    ]
    top_ham_features = [
        {"word": feature_names[i], "weight": round(float(coefficients[i]), 4)}
        for i in top_ham_indices
    ]

    vocab_importance = {
        "top_spam_features": top_spam_features,
        "top_ham_features": top_ham_features,
    }

    # 5. Save all artifacts
    logger.info("Saving models and metadata artifacts...")
    joblib.dump(best_pipeline, os.path.join(models_dir, "best_model_pipeline.joblib"))
    joblib.dump(trained_pipelines, os.path.join(models_dir, "all_models.joblib"))
    joblib.dump(tfidf_vectorizer, os.path.join(models_dir, "vectorizer.joblib"))

    # Save test data for offline evaluation plots and error analysis
    test_eval_data = {
        "X_test": X_test_raw.tolist(),
        "y_test": y_test.tolist(),
        "predictions": {name: pipe.predict(X_test_raw).tolist() for name, pipe in trained_pipelines.items()},
        "probabilities": {name: pipe.predict_proba(X_test_raw)[:, 1].tolist() for name, pipe in trained_pipelines.items()},
    }
    with open(os.path.join(models_dir, "test_eval_data.json"), "w") as f:
        json.dump(test_eval_data, f)

    payload = {
        "best_model_name": best_model_name,
        "dataset_statistics": dataset_stats,
        "models": results,
    }
    with open(os.path.join(models_dir, "model_metrics.json"), "w") as f:
        json.dump(payload, f, indent=2)

    with open(os.path.join(models_dir, "vocab_importance.json"), "w") as f:
        json.dump(vocab_importance, f, indent=2)

    logger.info("All model artifacts saved successfully in directory: " + models_dir)
    return payload


if __name__ == "__main__":
    train_and_evaluate_all()
