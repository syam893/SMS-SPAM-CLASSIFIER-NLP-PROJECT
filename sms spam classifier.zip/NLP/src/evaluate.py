"""
SMS Spam Classifier - Model Evaluation & Visualization Suite
Author: B.Tech CSE Capstone Project
Description: Generates high-resolution academic evaluation plots: confusion matrices,
             ROC curves, PR curves, model comparison charts, and in-depth error analysis.
"""

import os
import sys
import json
import logging
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for server/script rendering
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import roc_curve, precision_recall_curve, auc

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Modern theme styling
plt.style.use("seaborn-v0_8-whitegrid" if "seaborn-v0_8-whitegrid" in plt.style.available else "default")
PALETTE = ["#2563eb", "#10b981", "#f59e0b", "#8b5cf6"]


class ModelEvaluator:
    """Generates visual evaluation metrics, comparative charts, and error analysis."""

    def __init__(self, models_dir: str = "models", output_dir: str = "static/img/eval"):
        self.models_dir = models_dir
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

        with open(os.path.join(self.models_dir, "model_metrics.json"), "r") as f:
            self.metrics_data = json.load(f)

        with open(os.path.join(self.models_dir, "test_eval_data.json"), "r") as f:
            self.test_eval_data = json.load(f)

        with open(os.path.join(self.models_dir, "vocab_importance.json"), "r") as f:
            self.vocab_data = json.load(f)

    def plot_confusion_matrices(self):
        """Plots a 2x2 grid of confusion matrices for all 4 evaluated models."""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        axes = axes.flatten()

        model_names = list(self.metrics_data["models"].keys())
        labels = ["Ham (Legit)", "Spam"]

        for idx, name in enumerate(model_names):
            cm = np.array(self.metrics_data["models"][name]["confusion_matrix"])
            ax = axes[idx]
            sns.heatmap(
                cm,
                annot=True,
                fmt="d",
                cmap="Blues" if idx % 2 == 0 else "Purples",
                cbar=False,
                xticklabels=labels,
                yticklabels=labels,
                ax=ax,
                annot_kws={"size": 14, "weight": "bold"},
            )
            ax.set_title(f"{name}\n(Acc: {self.metrics_data['models'][name]['test_accuracy']*100:.2f}%, F1: {self.metrics_data['models'][name]['test_f1']:.4f})", fontsize=12, fontweight="bold")
            ax.set_ylabel("True Class", fontsize=10)
            ax.set_xlabel("Predicted Class", fontsize=10)

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, "confusion_matrices.png")
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close()
        logger.info(f"Saved confusion matrices to {save_path}")

    def plot_roc_curves(self):
        """Plots ROC Curves for all models on the unseen test set."""
        plt.figure(figsize=(9, 7))
        y_true = np.array(self.test_eval_data["y_test"])

        for idx, (name, probs) in enumerate(self.test_eval_data["probabilities"].items()):
            fpr, tpr, _ = roc_curve(y_true, probs)
            roc_auc = auc(fpr, tpr)
            plt.plot(
                fpr,
                tpr,
                lw=2.5,
                color=PALETTE[idx % len(PALETTE)],
                label=f"{name} (AUC = {roc_auc:.4f})",
            )

        plt.plot([0, 1], [0, 1], color="gray", lw=1.5, linestyle="--", label="Random Baseline (AUC = 0.5000)")
        plt.xlim([-0.01, 1.0])
        plt.ylim([0.0, 1.02])
        plt.xlabel("False Positive Rate (1 - Specificity)", fontsize=11, fontweight="bold")
        plt.ylabel("True Positive Rate (Sensitivity / Recall)", fontsize=11, fontweight="bold")
        plt.title("Receiver Operating Characteristic (ROC) Comparison", fontsize=14, fontweight="bold")
        plt.legend(loc="lower right", fontsize=10, frameon=True)
        plt.grid(True, linestyle="--", alpha=0.6)

        save_path = os.path.join(self.output_dir, "roc_curves.png")
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close()
        logger.info(f"Saved ROC curves to {save_path}")

    def plot_precision_recall_curves(self):
        """Plots Precision-Recall curves, crucial for imbalanced SMS spam data."""
        plt.figure(figsize=(9, 7))
        y_true = np.array(self.test_eval_data["y_test"])

        for idx, (name, probs) in enumerate(self.test_eval_data["probabilities"].items()):
            precision, recall, _ = precision_recall_curve(y_true, probs)
            pr_auc = auc(recall, precision)
            plt.plot(
                recall,
                precision,
                lw=2.5,
                color=PALETTE[idx % len(PALETTE)],
                label=f"{name} (PR-AUC = {pr_auc:.4f})",
            )

        baseline = np.sum(y_true) / len(y_true)
        plt.axhline(y=baseline, color="gray", linestyle="--", label=f"No-Skill Baseline ({baseline:.3f})")
        plt.xlim([0.0, 1.02])
        plt.ylim([0.0, 1.02])
        plt.xlabel("Recall", fontsize=11, fontweight="bold")
        plt.ylabel("Precision", fontsize=11, fontweight="bold")
        plt.title("Precision-Recall (PR) Curves Comparison", fontsize=14, fontweight="bold")
        plt.legend(loc="lower left", fontsize=10, frameon=True)
        plt.grid(True, linestyle="--", alpha=0.6)

        save_path = os.path.join(self.output_dir, "pr_curves.png")
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close()
        logger.info(f"Saved PR curves to {save_path}")

    def plot_model_comparison(self):
        """Generates a side-by-side grouped bar chart comparing key metrics."""
        models = self.metrics_data["models"]
        names = list(models.keys())
        metrics = ["test_accuracy", "test_precision", "test_recall", "test_f1", "test_roc_auc"]
        labels = ["Accuracy", "Precision", "Recall", "F1-Score", "ROC-AUC"]

        x = np.arange(len(names))
        width = 0.16
        fig, ax = plt.subplots(figsize=(13, 7))

        colors = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"]

        for i, (metric, label) in enumerate(zip(metrics, labels)):
            values = [models[m][metric] for m in names]
            rects = ax.bar(x + (i - 2) * width, values, width, label=label, color=colors[i], alpha=0.9)
            # Add small value labels above bars
            for rect in rects:
                height = rect.get_height()
                ax.annotate(
                    f"{height:.2f}",
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),
                    textcoords="offset points",
                    ha="center",
                    va="bottom",
                    fontsize=8,
                    rotation=90,
                )

        ax.set_ylabel("Score (0.0 to 1.0)", fontsize=11, fontweight="bold")
        ax.set_title("Comprehensive Machine Learning Benchmark on Test Data", fontsize=14, fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels(names, fontsize=11, fontweight="bold")
        ax.set_ylim(0.7, 1.08)
        ax.legend(loc="lower right", fontsize=10, frameon=True)
        ax.grid(True, linestyle="--", alpha=0.5, axis="y")

        save_path = os.path.join(self.output_dir, "model_comparison.png")
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close()
        logger.info(f"Saved model comparison chart to {save_path}")

    def plot_feature_importance(self):
        """Plots top 15 Spam and top 15 Ham indicative vocabulary tokens."""
        top_spam = self.vocab_data["top_spam_features"][:15]
        top_ham = self.vocab_data["top_ham_features"][:15]

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

        # Top Spam Words
        words_spam = [item["word"] for item in top_spam][::-1]
        weights_spam = [item["weight"] for item in top_spam][::-1]
        ax1.barh(words_spam, weights_spam, color="#dc2626", alpha=0.85)
        ax1.set_title("Top 15 SPAM Predictive Words (Positive Weights)", fontsize=12, fontweight="bold")
        ax1.set_xlabel("Logistic Regression Coefficient Weight", fontsize=10)
        ax1.grid(True, linestyle="--", alpha=0.5)

        # Top Ham Words
        words_ham = [item["word"] for item in top_ham][::-1]
        weights_ham = [abs(item["weight"]) for item in top_ham][::-1]
        ax2.barh(words_ham, weights_ham, color="#16a34a", alpha=0.85)
        ax2.set_title("Top 15 HAM Predictive Words (Negative Weights)", fontsize=12, fontweight="bold")
        ax2.set_xlabel("Absolute Logistic Regression Coefficient Weight", fontsize=10)
        ax2.grid(True, linestyle="--", alpha=0.5)

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, "feature_importance.png")
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close()
        logger.info(f"Saved feature importance chart to {save_path}")

    def plot_dataset_distributions(self):
        """Visualizes class distribution and character length distributions."""
        stats = self.metrics_data["dataset_statistics"]
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

        # Class pie chart
        counts = [stats["ham_count"], stats["spam_count"]]
        labels = [f"Ham ({stats['ham_percentage']}%)", f"Spam ({stats['spam_percentage']}%)"]
        colors = ["#22c55e", "#ef4444"]
        ax1.pie(counts, labels=labels, autopct="%1.1f%%", colors=colors, startangle=140, explode=(0, 0.1), shadow=True)
        ax1.set_title("Dataset Class Distribution (Cleaned SMS)", fontsize=12, fontweight="bold")

        # Average Length Bar Chart
        categories = ["Ham (Legitimate)", "Spam"]
        lengths = [stats["avg_char_length_ham"], stats["avg_char_length_spam"]]
        bars = ax2.bar(categories, lengths, color=["#3b82f6", "#f97316"], width=0.5)
        for bar in bars:
            h = bar.get_height()
            ax2.annotate(f"{h:.1f} chars", xy=(bar.get_x() + bar.get_width()/2, h), xytext=(0, 3), textcoords="offset points", ha="center", fontweight="bold")
        ax2.set_title("Average Message Length by Category", fontsize=12, fontweight="bold")
        ax2.set_ylabel("Average Characters", fontsize=10)
        ax2.grid(True, linestyle="--", alpha=0.5, axis="y")

        plt.tight_layout()
        save_path = os.path.join(self.output_dir, "dataset_distribution.png")
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close()
        logger.info(f"Saved dataset distribution charts to {save_path}")

    def run_error_analysis(self):
        """Performs qualitative error analysis on False Positives and False Negatives."""
        y_true = np.array(self.test_eval_data["y_test"])
        best_model = self.metrics_data["best_model_name"]
        preds = np.array(self.test_eval_data["predictions"][best_model])
        probs = np.array(self.test_eval_data["probabilities"][best_model])
        texts = self.test_eval_data["X_test"]

        false_positives = []
        false_negatives = []

        for text, true_lbl, pred_lbl, prob in zip(texts, y_true, preds, probs):
            if true_lbl == 0 and pred_lbl == 1:
                false_positives.append({
                    "text": text,
                    "spam_probability": round(float(prob), 4),
                    "reason": "Legitimate message containing promotional, numeric, or trigger-like keywords."
                })
            elif true_lbl == 1 and pred_lbl == 0:
                false_negatives.append({
                    "text": text,
                    "spam_probability": round(float(prob), 4),
                    "reason": "Spam message using conversational phrasing or evasive spelling."
                })

        error_report = {
            "best_model_evaluated": best_model,
            "total_test_samples": len(y_true),
            "false_positive_count": len(false_positives),
            "false_negative_count": len(false_negatives),
            "sample_false_positives": false_positives[:5],
            "sample_false_negatives": false_negatives[:5],
        }

        with open(os.path.join(self.output_dir, "error_analysis.json"), "w") as f:
            json.dump(error_report, f, indent=2)

        logger.info(f"Error analysis completed. FP: {len(false_positives)}, FN: {len(false_negatives)}")
        return error_report

    def run_all(self):
        """Executes all evaluation and visualization pipelines."""
        logger.info("Generating evaluation charts...")
        self.plot_confusion_matrices()
        self.plot_roc_curves()
        self.plot_precision_recall_curves()
        self.plot_model_comparison()
        self.plot_feature_importance()
        self.plot_dataset_distributions()
        error_rep = self.run_error_analysis()
        logger.info("All evaluation visualizations and error analysis generated successfully!")
        return error_rep


if __name__ == "__main__":
    evaluator = ModelEvaluator()
    evaluator.run_all()
