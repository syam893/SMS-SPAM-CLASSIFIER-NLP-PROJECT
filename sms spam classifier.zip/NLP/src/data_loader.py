"""
SMS Spam Classifier - Dataset Loader & Management Module
Author: B.Tech CSE Capstone Project
Description: Handles downloading, loading, cleaning, deduplication, exploration,
             and stratified train-test splitting of the SMS Spam Collection dataset.
"""

import os
import sys
import ssl
import logging
import urllib.request
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# Primary & fallback URLs for the SMS Spam Collection dataset
DATASET_URLS = [
    "https://raw.githubusercontent.com/justmarkham/DAT8/master/data/sms.tsv",
    "https://raw.githubusercontent.com/stedy/Machine-Learning-with-R-datasets/master/sms_spam.csv",
]


class DatasetManager:
    """Manages acquisition, validation, cleaning, and partitioning of SMS data."""

    def __init__(self, raw_path="data/raw/sms_spam_raw.csv", processed_path="data/processed/sms_spam_cleaned.csv"):
        self.raw_path = raw_path
        self.processed_path = processed_path
        os.makedirs(os.path.dirname(self.raw_path), exist_ok=True)
        os.makedirs(os.path.dirname(self.processed_path), exist_ok=True)

    def fetch_dataset(self, force_download=False):
        """Fetches the SMS Spam Collection dataset from online mirrors if not cached."""
        if os.path.exists(self.raw_path) and not force_download:
            logger.info(f"Raw dataset already exists at {self.raw_path}")
            return self.raw_path

        logger.info("Downloading SMS Spam Collection dataset...")
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        downloaded = False
        for url in DATASET_URLS:
            try:
                logger.info(f"Attempting download from {url}...")
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
                with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
                    content = response.read().decode("utf-8", errors="replace")

                # Parse TSV or CSV
                if "\t" in content.split("\n")[0] or url.endswith(".tsv"):
                    rows = []
                    for line in content.strip().split("\n"):
                        parts = line.split("\t")
                        if len(parts) >= 2:
                            label = parts[0].strip().lower()
                            text = "\t".join(parts[1:]).strip()
                            if label in ["ham", "spam"]:
                                rows.append({"label": label, "text": text})
                    df = pd.DataFrame(rows)
                else:
                    import io
                    df = pd.read_csv(io.StringIO(content), encoding="utf-8")
                    if "type" in df.columns and "text" in df.columns:
                        df = df.rename(columns={"type": "label"})
                    elif "v1" in df.columns and "v2" in df.columns:
                        df = df.rename(columns={"v1": "label", "v2": "text"})

                if len(df) > 1000:
                    df.to_csv(self.raw_path, index=False)
                    logger.info(f"Dataset successfully downloaded ({len(df)} records) -> {self.raw_path}")
                    downloaded = True
                    break
            except Exception as e:
                logger.warning(f"Download attempt from {url} failed: {e}")

        if not downloaded:
            raise RuntimeError("Could not download SMS Spam dataset from any remote mirror.")

        return self.raw_path

    def load_and_clean_data(self, remove_duplicates=True):
        """
        Loads the raw SMS data, checks nulls, removes duplicates, and standardizes labels.
        Returns:
            df_cleaned (pd.DataFrame): Cleaned dataframe with columns ['label', 'text', 'label_num']
            stats (dict): Summary statistics of dataset prior to and after cleaning.
        """
        self.fetch_dataset()
        df = pd.read_csv(self.raw_path)

        # Standardize column names
        df.columns = [col.strip().lower() for col in df.columns]
        if "v1" in df.columns and "v2" in df.columns:
            df = df.rename(columns={"v1": "label", "v2": "text"})
        elif "type" in df.columns:
            df = df.rename(columns={"type": "label"})

        initial_count = len(df)
        logger.info(f"Initial raw record count: {initial_count}")

        # Check for missing values
        null_count = df[["label", "text"]].isnull().sum().to_dict()
        df = df.dropna(subset=["label", "text"])

        # Normalize text and labels
        df["label"] = df["label"].astype(str).str.strip().str.lower()
        df = df[df["label"].isin(["ham", "spam"])]
        df["text"] = df["text"].astype(str).str.strip()

        # Check for empty text
        df = df[df["text"].str.len() > 0]

        # Duplicate handling
        duplicate_count = int(df.duplicated(subset=["text"]).sum())
        logger.info(f"Found {duplicate_count} duplicate messages.")
        if remove_duplicates:
            df = df.drop_duplicates(subset=["text"], keep="first").reset_index(drop=True)
            logger.info(f"Duplicates removed. Remaining records: {len(df)}")

        # Add numeric label: ham -> 0, spam -> 1
        df["label_num"] = df["label"].map({"ham": 0, "spam": 1})

        # Save processed dataset
        df.to_csv(self.processed_path, index=False)
        logger.info(f"Processed dataset saved to {self.processed_path}")

        # Generate summary statistics
        ham_count = int((df["label"] == "ham").sum())
        spam_count = int((df["label"] == "spam").sum())
        total = len(df)

        stats = {
            "initial_raw_records": initial_count,
            "null_values_dropped": null_count,
            "duplicates_removed": duplicate_count if remove_duplicates else 0,
            "final_clean_records": total,
            "ham_count": ham_count,
            "spam_count": spam_count,
            "ham_percentage": round((ham_count / total) * 100, 2) if total else 0.0,
            "spam_percentage": round((spam_count / total) * 100, 2) if total else 0.0,
            "avg_char_length_ham": round(float(df[df["label"] == "ham"]["text"].str.len().mean()), 2),
            "avg_char_length_spam": round(float(df[df["label"] == "spam"]["text"].str.len().mean()), 2),
        }
        return df, stats

    def get_train_test_split(self, test_size=0.2, random_state=42, remove_duplicates=True):
        """
        Performs stratified train/test split to prevent data leakage and preserve class distribution.
        Returns:
            X_train (pd.Series), X_test (pd.Series), y_train (pd.Series), y_test (pd.Series), stats (dict)
        """
        df, stats = self.load_and_clean_data(remove_duplicates=remove_duplicates)
        X = df["text"]
        y = df["label_num"]

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )

        split_info = {
            "train_size": len(X_train),
            "test_size": len(X_test),
            "train_ham": int((y_train == 0).sum()),
            "train_spam": int((y_train == 1).sum()),
            "test_ham": int((y_test == 0).sum()),
            "test_spam": int((y_test == 1).sum()),
        }
        stats["split_info"] = split_info

        logger.info(f"Train set: {len(X_train)} samples ({split_info['train_spam']} spam, {split_info['train_ham']} ham)")
        logger.info(f"Test set: {len(X_test)} samples ({split_info['test_spam']} spam, {split_info['test_ham']} ham)")

        return X_train, X_test, y_train, y_test, stats


if __name__ == "__main__":
    manager = DatasetManager()
    df, stats = manager.load_and_clean_data()
    print("\nDataset Summary Statistics:")
    for k, v in stats.items():
        print(f"  {k}: {v}")
