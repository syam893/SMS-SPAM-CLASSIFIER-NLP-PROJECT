"""
SMS Spam Classifier - Real-time Prediction Service
Author: B.Tech CSE Capstone Project
Description: Orchestrates preprocessor, model pipeline inference, confidence scoring,
             risk level categorization, and explainability output.
"""

import os
import sys
import logging
import joblib
from typing import Dict, Any, List, Optional

# Add project root to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.preprocessor import extract_indicators, TextPreprocessor
from src.explainer import SpamExplainer

logger = logging.getLogger(__name__)


class SpamPredictor:
    """Production-grade inference engine for real-time and batch SMS spam classification."""

    def __init__(self, models_dir: str = "models"):
        self.models_dir = models_dir
        self.preprocessor = TextPreprocessor(method="lemma", remove_stopwords=True)
        self.best_pipeline = None
        self.all_pipelines = {}
        self.metrics_summary = {}
        self.explainer = None
        self._load_models()

    def _load_models(self):
        """Loads trained pipelines and configuration from disk."""
        best_path = os.path.join(self.models_dir, "best_model_pipeline.joblib")
        all_path = os.path.join(self.models_dir, "all_models.joblib")

        if os.path.exists(best_path):
            self.best_pipeline = joblib.load(best_path)
            logger.info("Loaded best model pipeline.")
            self.explainer = SpamExplainer(self.best_pipeline)

        if os.path.exists(all_path):
            self.all_pipelines = joblib.load(all_path)
            logger.info(f"Loaded {len(self.all_pipelines)} candidate model pipelines.")

    def predict(self, text: str, model_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Classifies a single SMS message.
        Args:
            text (str): Raw SMS text.
            model_name (str, optional): Target model. Defaults to best performing model.
        Returns:
            Dict[str, Any]: Prediction result, probabilities, risk level, and explanations.
        """
        if not text or not text.strip():
            return {
                "error": "Empty or invalid message input provided.",
                "prediction": "Unknown",
                "confidence": 0.0,
            }

        cleaned_input = text.strip()

        # Select pipeline
        if model_name and model_name in self.all_pipelines:
            pipeline = self.all_pipelines[model_name]
            explainer = SpamExplainer(pipeline, model_name=model_name)
        elif self.best_pipeline is not None:
            pipeline = self.best_pipeline
            explainer = self.explainer or SpamExplainer(self.best_pipeline)
        else:
            raise RuntimeError("Model pipeline not loaded. Please train models first.")

        # Inference
        pred_label_num = int(pipeline.predict([cleaned_input])[0])
        probabilities = pipeline.predict_proba([cleaned_input])[0]
        ham_prob = float(probabilities[0])
        spam_prob = float(probabilities[1])

        prediction = "Spam" if pred_label_num == 1 else "Ham"
        confidence = spam_prob if prediction == "Spam" else ham_prob

        # Categorize Risk Level
        if spam_prob >= 0.80:
            risk_level = "CRITICAL RISK"
            risk_color = "#dc2626"
        elif spam_prob >= 0.50:
            risk_level = "HIGH RISK"
            risk_color = "#ea580c"
        elif spam_prob >= 0.25:
            risk_level = "MODERATE / SUSPICIOUS"
            risk_color = "#ca8a04"
        else:
            risk_level = "SAFE / LEGITIMATE"
            risk_color = "#16a34a"

        # Generate Explainability & Feature Attribution
        explanation = explainer.explain_message(cleaned_input, spam_prob, prediction)

        return {
            "raw_text": cleaned_input,
            "cleaned_tokens": self.preprocessor.preprocess(cleaned_input),
            "prediction": prediction,
            "is_spam": bool(pred_label_num == 1),
            "confidence": round(confidence * 100, 2),
            "spam_probability": round(spam_prob * 100, 2),
            "ham_probability": round(ham_prob * 100, 2),
            "risk_level": risk_level,
            "risk_color": risk_color,
            "model_used": model_name or "Best Model (Auto-selected)",
            "explanation": explanation,
        }

    def predict_batch(self, messages: List[str], model_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Processes a list of raw SMS messages in batch mode."""
        results = []
        for msg in messages:
            if msg and msg.strip():
                results.append(self.predict(msg, model_name=model_name))
        return results


# Global singleton instance
_predictor_instance = None


def get_predictor() -> SpamPredictor:
    global _predictor_instance
    if _predictor_instance is None:
        _predictor_instance = SpamPredictor()
    return _predictor_instance
